from hx3dtoolkit.utils.frozen_dict import FrozenDict
from hx3dtoolkit.utils.singleton import Singleton

import yaml
import yamlordereddictloader
import os

class Config(metaclass=Singleton):
    def __init__(self):
        directory = os.path.dirname(os.path.realpath(__file__))
        with open("{}/config.yml".format(directory), "r") as config_content:
            yaml_content = yaml.load(config_content.read(), Loader=yamlordereddictloader.Loader)
            self.config = FrozenDict(yaml_content, freeze_children=True)
        with open("{}/dependencies.yml".format(directory), "r") as dep_content:
            yaml_content = yaml.load(dep_content.read(), Loader=yamlordereddictloader.Loader)
            self.config["dependencies"] = FrozenDict(yaml_content, freeze_children=True)

config = Config().config
